import { ClienteResponseDto } from "src/domain/parent/cliente/dto/client.response.dto";
import { SucursalResponseDto } from "src/domain/parent/sucursal/dto/sucursal.response.dto";
import { SerieResponseDto } from "../../serie-comprobante/dto/reesponse.dto";


export class ComprobanteResponseDto {
  constructor(
    public comprobanteId: number,
    public numeroComprobante: number, // correlativo
    public fechaEmision: Date,
    public fechaVencimiento: Date,
    public moneda: string,

    // Totales
    public totalGravado: number,
    public totalExonerado: number,
    public totalInafecto: number,
    public totalIgv: number,
    public total: number,
    // fechas auditoria
    public fechaCreate: Date,
    public fechaUpdate: Date,
    // Estado
    public estado: string, // PENDIENTE, ACEPTADO, etc.
    public comunicadoSunat: string,
    public serieCorrelativo: string,
    // Relaciones
    public sucursalId: number,
    public clienteId: number | null,
    public serie?: SerieResponseDto | null,
    public comprobanteRespuestaSunat?: ComprobanteRespuestaSunatResponseDto | null,
    // Datos adicionales
    public payloadJson?: any,
    public fechaAnulacion?: Date,
    public descripcionEstado?: string,
    public icbper?: number,
  ) {}
}

export class ComprobanteRespuestaSunatResponseDto {
  constructor(
    public comprobanteRsptId: number, // ID autoincremental
    public xmlFirmado: string, // XML firmado (base64 o string largo)
    public hashCpe: string, // Hash del CPE (cadena de hasta 100)
    public cdr: Buffer, // CDR como binario (puedes devolver base64 en API)
    public createdAt: Date, // Fecha de creación
  ) {}
}
