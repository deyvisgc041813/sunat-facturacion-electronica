import { Injectable, NotFoundException } from '@nestjs/common';
import { TenantConnectionRepositoryImpl } from 'src/infrastructure/persistence/parent/implement/coneccion-database.repository.impl';
import { DataSource, DataSourceOptions } from 'typeorm';
import * as tenantEntities from '../../../../infrastructure/persistence/tenant/entity/index';
import { EEstadosGlobales } from 'src/util/estado.enum';
/**
 * Servicio de gestión de bases de datos multi-tenant (una BD por sucursal)
 * - 🔹 Lazy connection (solo conecta cuando se necesita)
 * - 🔹 TTL de inactividad (cierra conexiones que no se usan)
 * - 🔹 Mutex (evita crear dos conexiones simultáneamente)
 * - 🔹 Validación de nombres de base de datos
 * - 🔹 Sin `synchronize: true` (seguro para producción)
 * - 🔹 Validación de tenants activos
 */
@Injectable()
export class TenantDatabaseService {
  // Conexiones activas
  private connections: Map<string, DataSource> = new Map();
  // Mutex para evitar doble inicialización simultánea
  private initializing: Map<string, Promise<DataSource>> = new Map();

  // Timers para cierre por inactividad
  private idleTimers: Map<string, NodeJS.Timeout> = new Map();

  // Tiempo de vida máximo de una conexión sin uso (en minutos)
  private readonly TTL_MIN = Number(process.env.TENANT_TTL_MIN || 15);

  constructor(private readonly tenantRepo: TenantConnectionRepositoryImpl) {}
  /**
   * Se Crea la base de datos si no existe
   * Seguridad incluida: evita inyección SQL en el nombre
   */
  private async createDatabaseIfNotExists(dbName: string): Promise<void> {
    if (!/^[a-zA-Z0-9_]+$/.test(dbName)) {
      throw new Error('Nombre de base de datos inválido');
    }
    const tempDS = new DataSource({
      type: 'mysql',
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '3306', 10),
      username: process.env.DB_USER_TENANT || 'root',
      password: process.env.DB_PASS_TENANT || '',
      database: 'mysql',
    });
    try {
      await tempDS.initialize();
      await tempDS.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\``);
    } finally {
      await tempDS.destroy();
    }
  }

  /**
   * Crea una conexión de tenant (solo si no existe)
   * Incluye validación, migraciones y registro en caché
   */
  private async createTenantConnectionLocked(
    subDominio: string,
    dbName: string,
  ): Promise<DataSource> {
    await this.createDatabaseIfNotExists(dbName);
    const entitiesArray = Array.isArray(tenantEntities)
      ? tenantEntities
      : Object.values(tenantEntities);

    const options: DataSourceOptions = {
      type: 'mysql',
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '3306', 10),
      username: process.env.DB_USER_TENANT || 'root',
      password: process.env.DB_PASS_TENANT || '',
      database: dbName,
      entities: entitiesArray,
      synchronize: false, // ⚠️ Seguro en producción (usar migraciones)
      migrationsRun: true, // Corre migraciones automáticamente
      migrations: [
        __dirname +
          '/../../../../infrastructure/persistence/tenant/migrations/*{.ts,.js}',
      ],
      logging: false,
    };

    const dataSource = new DataSource(options);
    await dataSource.initialize();
    this.connections.set(subDominio, dataSource);
    this.resetIdleTimer(subDominio);
    await this.autoGenerateAndRunMigrations(dataSource);
    console.log(`Tenant conectado: ${subDominio}`);

    return dataSource;
  }

  /**
   * Cierra conexión por inactividad (TTL)
   * Libera memoria y sockets MySQL automáticamente
   */
  private resetIdleTimer(subDominio: string): void {
    if (this.idleTimers.has(subDominio)) {
      clearTimeout(this.idleTimers.get(subDominio)!);
    }
    const timer = setTimeout(
      async () => {
        const ds = this.connections.get(subDominio);
        if (ds && ds.isInitialized) {
          await ds.destroy();
          console.log(`Conexión cerrada por inactividad: ${subDominio}`);
        }
        this.connections.delete(subDominio);
        this.idleTimers.delete(subDominio);
      },
      this.TTL_MIN * 60 * 1000,
    );

    this.idleTimers.set(subDominio, timer);
  }
  // Inicializa conexiones de todos los tenants activos

  // async initializeConnections(): Promise<void> {
  //   const tenants = await this.tenantRepo.findAllActive();
  //   for (const tenant of tenants) {
  //     await this.createTenantConnection(tenant?.sucursal?.subDominio, tenant.dbName);
  //   }
  // }
  // async activateTenant(sucuresalId:number, subDominio: string): Promise<void> {
  //   const dbName = `${subDominio}_db`;
  //   await this.tenantRepo.save(sucuresalId, dbName);
  //   await this.createTenantConnection(subDominio, dbName);
  //   await this.tenantRepo.activate(sucuresalId, dbName);
  // }

  // async createTenantConnection(
  //   subDominio: string,
  //   dbName: string,
  // ): Promise<DataSource> {
  //   if (this.connections.has(subDominio)) {
  //     return this.connections.get(subDominio)!;
  //   }
  //   await this.createDatabaseIfNotExists(dbName);
  //   const { default: tenantEntities } = await import('../../../../infrastructure/persistence/tenant/entity/index.js');
  //   const entitiesArray = Array.isArray(tenantEntities) ? tenantEntities: Object.values(tenantEntities);
  //   try {
  //     const options: DataSourceOptions = {
  //     type: 'mysql',
  //     host: process.env.DB_HOST || 'localhost',
  //     port: parseInt(process.env.DB_PORT || '3306', 10),
  //     username: process.env.DB_USER_TENANT || 'root',
  //     password: process.env.DB_PASS_TENANT || '',
  //     database: dbName,
  //     entities: entitiesArray,
  //     synchronize: true,
  //     logging: false,
  //   };
  //   const dataSource = new DataSource(options);
  //   await dataSource.initialize();
  //   this.connections.set(subDominio, dataSource);
  //   return dataSource;
  //   } catch (error: any) {
  //   console.log(error)
  //   throw error
  //   }
  // }

  // async getTenantConnection(tenantName: string): Promise<DataSource> {
  //    const connection = this.connections.get(tenantName);
  //   if (!connection) {
  //     throw new InternalServerErrorException(
  //       `No se encontró conexión configurada para el tenant "${tenantName}".`,
  //     );
  //   }
  //   return connection;
  // }
  /**
   * Obtiene o crea una conexión del tenant (lazy seguro)
   * - Valida que el tenant esté activo
   * - Usa mutex para evitar doble inicialización
   * - Actualiza TTL cada vez que se usa
   */
  async getTenantConnection(subDominio: string): Promise<DataSource> {
    // Si ya existe, devuélvela y reinicia el TTL
    const existing = this.connections.get(subDominio);
    if (existing?.isInitialized) {
      this.resetIdleTimer(subDominio);
      return existing;
    }

    // Evita inicializaciones duplicadas (mutex)
    if (this.initializing.has(subDominio)) {
      return this.initializing.get(subDominio)!;
    }
    // Busca tenant en la base principal
    const tenant = await this.tenantRepo.findBySubDominio(subDominio);
    if (!tenant || tenant.estado !== EEstadosGlobales.ACTIVO) {
      throw new NotFoundException(
        `Tenant "${subDominio}" no está activo o no existe.`,
      );
    }
    // Crea conexión protegida por mutex
    const promise = this.createTenantConnectionLocked(
      subDominio,
      tenant.dbName,
    ).finally(() => this.initializing.delete(subDominio));
    this.initializing.set(subDominio, promise);
    return promise;
  }

  /**
   * Cierra manualmente una conexión de tenant (ej. baja de sucursal)
   */
  async closeTenantConnection(subDominio: string): Promise<void> {
    const connection = this.connections.get(subDominio);
    if (connection?.isInitialized) {
      await connection.destroy();
      console.log(`Conexión del tenant cerrada manualmente: ${subDominio}`);
    }
    this.connections.delete(subDominio);
    const timer = this.idleTimers.get(subDominio);
    if (timer) clearTimeout(timer);
    this.idleTimers.delete(subDominio);
  }
  /**
   * Activa un nuevo tenant (crea BD y lo registra)
   * No conecta aún — se conectará cuando se use por primera vez (lazy)
   */
  async activateTenant(sucursalId: number, subDominio: string): Promise<void> {
    const dbName = `${subDominio}_db`;
    await this.tenantRepo.save(sucursalId, dbName);
    await this.createTenantConnectionLocked(subDominio, dbName);
    await this.tenantRepo.activate(sucursalId, dbName);
    console.log(`Tenant ${subDominio} activado con base ${dbName}`);
  }
  /**
   * Lista de conexiones activas actualmente
   */
  listActiveConnections(): string[] {
    return Array.from(this.connections.keys());
  }

  /**
   * Genera automáticamente una migración si hay cambios en las entidades
   * y la ejecuta sobre el DataSource indicado.
   */
  async autoGenerateAndRunMigrations(dataSource: DataSource) {
    const queryRunner = dataSource.createQueryRunner();

    try {
      console.log(
        `Verificando cambios de esquema en ${dataSource.options.database}...`,
      );

      // Construir el esquema actual de la base de datos
      const schemaBuilder = dataSource.driver.createSchemaBuilder();
      const syncQueries = await schemaBuilder.log();

      // Si no hay cambios, salir
      if (!syncQueries || syncQueries.upQueries.length === 0) {
        console.log(
          `No hay cambios de esquema en ${dataSource.options.database}`,
        );
        return;
      }

      // Mostrar las queries detectadas (opcional)
      console.log(`⚙️ Cambios detectados para ${dataSource.options.database}:`);
      for (const q of syncQueries.upQueries) {
        console.log('   »', q.query);
      }

      // 4Ejecutar los cambios
      console.log(`🏗️ Aplicando cambios de esquema automáticamente...`);
      for (const q of syncQueries.upQueries) {
        await queryRunner.query(q.query);
      }

      console.log(
        `Migración automática aplicada correctamente en ${dataSource.options.database}`,
      );
    } catch (err) {
      console.error(
        `Error ejecutando migración automática en ${dataSource.options.database}:`,
        err,
      );
      throw err;
    } finally {
      await queryRunner.release();
    }
  }
}
