
import { Injectable, Scope } from '@nestjs/common';
@Injectable({ scope: Scope.REQUEST })
export class TenantContextService {
  private subDominio: string;

  setSubDominio(subDominio: string) {
    this.subDominio = subDominio;
  }

  getSubDominio(): string {
    return this.subDominio;
  }
}
