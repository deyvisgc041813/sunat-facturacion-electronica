

export interface ITenantDatabaseRepositoryPort {
  initializeConnections();
//   saveAndActivateTenant(sucursalId: number, subDominio: string): Promise<void>;
}
