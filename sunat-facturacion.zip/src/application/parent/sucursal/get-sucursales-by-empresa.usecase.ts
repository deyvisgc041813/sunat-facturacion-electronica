import { UnauthorizedException } from '@nestjs/common';
import { SucursalResponseDto } from 'src/domain/parent/sucursal/dto/sucursal.response.dto';
import { SucursalService } from 'src/domain/parent/sucursal/service/sucursal.service';
export class GetSucursalByEmpresaUseCase {
  constructor(private readonly sucursalService: SucursalService) {}
  async execute(empresaId: number): Promise<SucursalResponseDto[]> {
    if (!empresaId || empresaId <= 0) {
      throw new UnauthorizedException(
        'Tu sesión no tiene una empresa asociada. Vuelve a iniciar sesión para continuar.',
      );
    }
    return this.sucursalService.getAll(empresaId);
  }
}
