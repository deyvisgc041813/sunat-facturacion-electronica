import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SunatLogMapper } from 'src/domain/mapper/sunat-log.mapper';
import { SunatLogOrmEntity } from '../../entity/sunat-log.orm.entity';
import { SunatLogRepository } from 'src/domain/tenant/sunat-log/port/sunat-log.repository.port';
import { CreateSunatLogDto, SunatLogResponseDto } from 'src/domain/tenant/sunat-log/interface/sunat.log.interface';

@Injectable()
export class SunatLogRepositoryImpl implements SunatLogRepository {
  constructor(
    @InjectRepository(SunatLogOrmEntity)
    private readonly repo: Repository<SunatLogOrmEntity>,
  ) {}

  async save(log: CreateSunatLogDto): Promise<{ status: boolean; message: string; data?: SunatLogResponseDto }> {
     await this.repo.save(SunatLogMapper.dtoToOrmCreate(log));
    return {
      status: true,
      message: 'log registrado correctamente',
    };
  }
  async findAll(): Promise<SunatLogResponseDto[]> {
    const result = await this.repo.find({
      relations: ['comprobante'],
    });
    return result.map((s) => SunatLogMapper.toDomain(s));
  }
  async findById(id: number): Promise<SunatLogResponseDto | null> {
    const serie = await this.repo.findOne({
      where: { id: id },
      relations: ['comprobante'],
    });
    if (!serie) {
      throw new NotFoundException(`Log con id ${id} no encontrado`);
    }
    return SunatLogMapper.toDomain(serie)
  }
}
