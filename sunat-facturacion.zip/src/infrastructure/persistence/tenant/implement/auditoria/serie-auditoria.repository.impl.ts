import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SerieAuditoriaOrmEntity } from '../../entity/serie-comprobante/serie-auditoria.orm.entity';
import { SerieAuditoriaMapper } from 'src/domain/mapper/serie-auditoria.mapper';
import { SerieAuditoriaRepository } from 'src/domain/tenant/series-auditoria/port/serie-auditoria.repository.port';
import { SerieAuditoriaResponseDto } from 'src/domain/tenant/series-auditoria/dto/serie-auditoria.response.dto';
import { CreateSerieAuditoriaDto } from 'src/domain/tenant/series-auditoria/dto/create.serie-auditoria.dto';
import { UpdateSerieDto } from 'src/domain/tenant/serie-comprobante/dto/update.request.dto';

@Injectable()
export class SerieAuditoriaRepositoryImpl implements SerieAuditoriaRepository {
  constructor(
    @InjectRepository(SerieAuditoriaOrmEntity)
    private readonly repo: Repository<SerieAuditoriaOrmEntity>,
  ) {}

  async save(serie: CreateSerieAuditoriaDto): Promise<{ status: boolean; message: string; data?: SerieAuditoriaResponseDto }> {
    const create = await this.repo.save(serie);
    return {
      status: true,
      message: 'log registrado correctamente',
      data: SerieAuditoriaMapper.toDomain(create),
    };
  }

  async findAll(): Promise<SerieAuditoriaResponseDto[]> {
    const result = await this.repo.find({
      relations: ['serie'],
    });
    return result.map((s) => SerieAuditoriaMapper.toDomain(s));
  }

  async findById(serieId: number): Promise<SerieAuditoriaResponseDto | null> {
    const serie = await this.repo.findOne({
      where: { serie: {serieId} },
      relations: ['serie'],
    });
    if (!serie) {
      throw new NotFoundException(`Log con id ${serieId} no encontrado`);
    }
    return SerieAuditoriaMapper.toDomain(serie)
  }
  async update(serie: UpdateSerieDto, serieId:number): Promise<{ status: boolean; message: string; data?: SerieAuditoriaResponseDto }> {
   
    await this.repo.update(serieId, SerieAuditoriaMapper.dtoToOrmUpdate(serie));
    return {
      status: true,
      message: 'Actualizado correctamente'
    };
  }
}
