import { Injectable, OnModuleInit } from '@nestjs/common';
import { DataSource, DataSourceOptions, Repository } from 'typeorm';
import { EEstadosGlobales } from 'src/util/estado.enum';
import { InjectRepository } from '@nestjs/typeorm';
import { TenantConnectionOrmEntity } from '../entity/tenant.coneccion.orm.entity';
import { ITenantDatabaseRepositoryPort } from 'src/domain/parent/conecciones-database/port/tenant-database.repository.port';
import { TenantConecctionMapper } from 'src/domain/mapper/tenant-connecction.mapper';
import { TenantConnectionsResponseDto } from 'src/domain/parent/conecciones-database/dto/tenant-database.response.dto';

@Injectable()
export class TenantConnectionRepositoryImpl implements ITenantDatabaseRepositoryPort {

  constructor(
    @InjectRepository(TenantConnectionOrmEntity)
    private readonly tenantRepo: Repository<TenantConnectionOrmEntity>,
  ) {}
  initializeConnections() {
    throw new Error('Method not implemented.');
  }
  createTenantConnection(ruc: string, dbName: string): Promise<DataSource | undefined> {
    throw new Error('Method not implemented.');
  }
  getTenantConnection(ruc: string): DataSource | undefined {
    throw new Error('Method not implemented.');
  }
  async save(sucursalId: number, dbName: string): Promise<void> {
    const saveOrm = new TenantConnectionOrmEntity()
    saveOrm.sucursal = ({ sucursalId: sucursalId } as any)
    saveOrm.dbName = dbName
    await this.tenantRepo.save(saveOrm);
  }

  async activate(sucursalId: number, dbName:string): Promise<void> {
    await this.tenantRepo.update({ sucursal: {sucursalId}, dbName }, { estado: EEstadosGlobales.ACTIVO });
  }

  async findBySubDominio(subDominio:string): Promise<TenantConnectionsResponseDto | null> {
    const coneccion = await this.tenantRepo.findOne({ where: { estado: EEstadosGlobales.ACTIVO, sucursal: {subDominio} }, relations: ["sucursal"] });
    if(!coneccion) return null
    return TenantConecctionMapper.toDomain(coneccion) 
  }
}