import { Entity, Column, PrimaryGeneratedColumn, OneToOne, JoinColumn } from 'typeorm';
import { SucursalOrmEntity } from './sucursal.orm.entity';

@Entity('tenant_connections')
export class TenantConnectionOrmEntity {
  @PrimaryGeneratedColumn({name: "coneccion_id"})
  coneccionId: number;
  @Column({name: "base_datos_nombre", type: "varchar", length: 255})
  dbName: string;  // Nombre de la base de datos hija asociada
  @Column({ type: "char", length: 1,  default: '1' })
  estado: string; 
  @Column({ name: "fecha_creacion", type: 'timestamp' })
  fechaRegistro: Date;
  @OneToOne(() => SucursalOrmEntity, (sucursal) => sucursal.tenantConnection)
  @JoinColumn({ name: 'sucursal_id' })
  sucursal: SucursalOrmEntity;
}
